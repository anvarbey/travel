<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Ordering</title>


    <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>

    <!-- Theme CSS -->
    <link href="css/agency2.min.css" rel="stylesheet">
    <link href="css/cssfortable.css" rel="stylesheet">

</head>

<body id="page-top" class="index">

   
    <nav id="mainNav" class="navbar navbar-default navbar-custom navbar-fixed-top">
        <div class="container">
       
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span> Menu <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand page-scroll" href="index.php">Get back</a>
            </div>

   
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="hidden">
                        <a href="#page-top"></a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#services">Make an Order</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#howitworks">How it works</a>
                    </li>
                            
                    <li>
                        <a class="page-scroll" href="#contact">Contact</a>
                    </li>
                </ul>
            </div>
          
        </div>
           </nav>
 
    <!-- Header -->
    <header>
        <div class="container">
            <div class="intro-text">
  
                <div class="intro-heading">E-booking</div>

            </div>
        </div>
    </header>

    <!-- Services Section -->
   <<?php
		if(isset($_GET['scriptname'])){
			$scriptname = $_GET['scriptname'];
			$tmp = explode('?',$_GET['scriptname']);
			$file = $tmp[0];
			$query = explode('=',$tmp[1]);
			$_GET[$query[0]] = $query[1];
			include('/booking_calendar/'.$file);
			// die(print_r($_GET));
		}
		else	
			include '/booking_calendar/user_login.php'; ?>
    <section id="services">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">E-Service</h2>
                    <h3 class="section-subheading text-muted">Fill the form to get booked</h3>
                </div>
            </div>
            <table></table>
             <div class="row text-center">

<!--   <table style="width: 100%;  class="listing" cellpadding="0" cellspacing="0" >
          <tr>
            <th class="first" width="177">Header Here</th>
            <th>C</th>
            <th>Delete</th>
            <th>Header</th>
            <th>Header</th>
            <th>Head</th>
            <th>Header</th>
            <th class="last">Head</th>
          </tr>
          <tr>
            <td class="first style1">PHP code right here</td>
            <td><img src="img/add-icon.gif" width="16" height="16" alt="" /></td>
            <td><img src="img/hr.gif" width="16" height="16" alt="" /></td>
            <td><img src="img/save-icon.gif" width="16" height="16" alt="" /></td>
            <td><img src="img/edit-icon.gif" width="16" height="16" alt="" /></td>
            <td><img src="img/login-icon.gif" width="16" height="16" alt="" /></td>
            <td><img src="img/save-icon.gif" width="16" height="16" alt="save" /></td>
            <td class="last"><img src="img/add-icon.gif" width="16" height="16" alt="add" /></td>
          </tr>
          <tr class="bg">
            <td class="first style2"> PHP code right here</td>
            <td><img src="img/add-icon.gif" width="16" height="16" alt="add" /></td>
            <td><img src="img/hr.gif" width="16" height="16" alt="" /></td>
            <td><img src="img/save-icon.gif" width="16" height="16" alt="save" /></td>
            <td><img src="img/edit-icon.gif" width="16" height="16" alt="edit" /></td>
            <td><img src="img/login-icon.gif" width="16" height="16" alt="login" /></td>
            <td><img src="img/save-icon.gif" width="16" height="16" alt="save" /></td>
            <td class="last"><img src="img/add-icon.gif" width="16" height="16" alt="add" /></td>
          </tr>
          <tr>
            <td class="first style3"> PHP code right here</td>
            <td><img src="img/add-icon.gif" width="16" height="16" alt="add" /></td>
            <td><img src="img/hr.gif" width="16" height="16" alt="" /></td>
            <td><img src="img/save-icon.gif" width="16" height="16" alt="save" /></td>
            <td><img src="img/edit-icon.gif" width="16" height="16" alt="edit" /></td>
            <td><img src="img/login-icon.gif" width="16" height="16" alt="login" /></td>
            <td><img src="img/save-icon.gif" width="16" height="16" alt="save" /></td>
            <td class="last"><img src="img/add-icon.gif" width="16" height="16" alt="add" /></td>
          </tr>
          <tr class="bg">
            <td class="first style1"> PHP code right here</td>
            <td><img src="img/add-icon.gif" width="16" height="16" alt="add" /></td>
            <td><img src="img/hr.gif" width="16" height="16" alt="" /></td>
            <td><img src="img/save-icon.gif" width="16" height="16" alt="save" /></td>
            <td><img src="img/edit-icon.gif" width="16" height="16" alt="edit" /></td>
            <td><img src="img/login-icon.gif" width="16" height="16" alt="login" /></td>
            <td><img src="img/save-icon.gif" width="16" height="16" alt="save" /></td>
            <td class="last"><img src="img/add-icon.gif" width="16" height="16" alt="add" /></td>
          </tr>
          <tr>
            <td class="first style2"> PHP code right here</td>
            <td><img src="img/add-icon.gif" width="16" height="16" alt="add" /></td>
            <td><img src="img/hr.gif" width="16" height="16" alt="" /></td>
            <td><img src="img/save-icon.gif" width="16" height="16" alt="save" /></td>
            <td><img src="img/edit-icon.gif" width="16" height="16" alt="edit" /></td>
            <td><img src="img/login-icon.gif" width="16" height="16" alt="login" /></td>
            <td><img src="img/save-icon.gif" width="16" height="16" alt="save" /></td>
            <td class="last"><img src="img/add-icon.gif" width="16" height="16" alt="add" /></td>
          </tr>
          <tr class="bg">
            <td class="first style3"> PHP code right here </td>
            <td><img src="img/add-icon.gif" width="16" height="16" alt="add" /></td>
            <td><img src="img/hr.gif" width="16" height="16" alt="" /></td>
            <td><img src="img/save-icon.gif" width="16" height="16" alt="save" /></td>
            <td><img src="img/edit-icon.gif" width="16" height="16" alt="edit" /></td>
            <td><img src="img/login-icon.gif" width="16" height="16" alt="login" /></td>
            <td><img src="img/save-icon.gif" width="16" height="16" alt="save" /></td>
            <td class="last"><img src="img/add-icon.gif" width="16" height="16" alt="add" /></td>
          </tr>
          <tr>
            <td class="first style4"> PHP code right here </td>
            <td><img src="img/add-icon.gif" width="16" height="16" alt="add" /></td>
            <td><img src="img/hr.gif" width="16" height="16" alt="" /></td>
            <td><img src="img/save-icon.gif" width="16" height="16" alt="save" /></td>
            <td><img src="img/edit-icon.gif" width="16" height="16" alt="edit" /></td>
            <td><img src="img/login-icon.gif" width="16" height="16" alt="login" /></td>
            <td><img src="img/save-icon.gif" width="16" height="16" alt="save" /></td>
            <td class="last"><img src="img/add-icon.gif" width="16" height="16" alt="add" /></td>
          </tr>
        </table>
     
            </div>
        </div>
    </section>

    <!-- Team Section -->
    <section id="team" class="bg-light-gray">
        <div class="howitworks">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Our Amazing Team</h2>
                    <h3 class="section-subheading text-muted">Anvarbey's team.</h3>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-4">
                    <div class="team-member">
                        <img src="img/team/1.jpg" class="img-responsive img-circle" alt="">
                        <h4>Sabina</h4>
                        <p class="text-muted">Lead Designer</p>
                        <ul class="list-inline social-buttons">
                            <li><a href="#"><i class="fa fa-twitter"></i></a>
                            </li>
                            <li><a href="#"><i class="fa fa-facebook"></i></a>
                            </li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="team-member">
                        <img src="img/team/2.jpg" class="img-responsive img-circle" alt="">
                        <h4>Anvarbey</h4>
                        <p class="text-muted">First Lead Developer</p>
                        <ul class="list-inline social-buttons">
                            <li><a href="#"><i class="fa fa-twitter"></i></a>
                            </li>
                            <li><a href="#"><i class="fa fa-facebook"></i></a>
                            </li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="team-member">
                        <img src="img/team/3.jpg" class="img-responsive img-circle" alt="">
                        <h4>Turabek</h4>
                        <p class="text-muted">Second Lead Developer</p>
                        <ul class="list-inline social-buttons">
                            <li><a href="#"><i class="fa fa-twitter"></i></a>
                            </li>
                            <li><a href="#"><i class="fa fa-facebook"></i></a>
                            </li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2 text-center">
                    <p class="large text-muted">Instructions right here</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Clients Aside -->
    <aside class="clients">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-6">
                    <a href="#">
                        <img src="img/logos/bakufiers.jpg" class="img-responsive img-centered" alt="">
                    </a>
                </div>
                <div class="col-md-3 col-sm-6">
                    <a href="#">
                        <img src="img/logos/tour.png" class="img-responsive img-centered" alt="">
                    </a>
                </div>
                <div class="col-md-3 col-sm-6">
                    <a href="#">
                        <img src="img/logos/uzbek.png" class="img-responsive img-centered" alt="">
                    </a>
                </div>
                <div class="col-md-3 col-sm-6">
                    <a href="#">
                        <img src="img/logos/creative-market.jpg" class="img-responsive img-centered" alt="">
                    </a>
                </div>
            </div>
        </div>
    </aside>

    <!-- Contact Section -->
    <section id="contact">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Contact Us</h2>
                    <h3 class="section-subheading text-muted">Contact us if you have any question!</h3>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <form name="sentMessage" id="contactForm" novalidate>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Your Name *" id="name" required data-validation-required-message="Please enter your name.">
                                    <p class="help-block text-danger"></p>
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control" placeholder="Your Email *" id="email" required data-validation-required-message="Please enter your email address.">
                                    <p class="help-block text-danger"></p>
                                </div>
                                <div class="form-group">
                                    <input type="tel" class="form-control" placeholder="Your Phone *" id="phone" required data-validation-required-message="Please enter your phone number.">
                                    <p class="help-block text-danger"></p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <textarea class="form-control" placeholder="Your Message *" id="message" required data-validation-required-message="Please enter a message."></textarea>
                                    <p class="help-block text-danger"></p>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-lg-12 text-center">
                                <div id="success"></div>
                                <button type="submit" class="btn btn-xl">Send Message</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-4">
           
                </div>
                <div class="col-md-4">
                    <ul class="list-inline social-buttons">
                       
                    </ul>
                </div>
                <div class="col-md-4">
                    <ul class="list-inline quicklinks">

                    </ul>
                </div>
            </div>
        </div>
    </footer>


    <!-- jQuery -->
    <script src="vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>

    <!-- Contact Form JavaScript -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>

    <!-- Theme JavaScript -->
    <script src="js/agency.min.js"></script>

</body>

</html>
