<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Travelling Page</title>

    <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>

    <!-- Theme CSS -->
    <link href="css/agency.min.css" rel="stylesheet">

</head>

<body id="page-top" class="index">

    <!-- Navigation -->
    <nav id="mainNav" class="navbar navbar-default navbar-custom navbar-fixed-top">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span> Menu <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand page-scroll" href="#page-top">Main view</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="hidden">
                        <a href="#page-top"></a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#services">Services</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#portfolio">Trips</a>
                    </li>
                   <!-- <li>
                        <a class="page-scroll" href="#about">About</a>
                    </li>-->
                    <li>
                        <a class="page-scroll" href="#team">Team</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#contact">Contact</a>
                    </li>
                </ul>  
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>

    <!-- Header -->
    <header>
        <div class="container">
            <div class="intro-text">
                <div class="intro-lead-in">Welcome to</div>
                <div class="intro-heading">World Travelling</div>
                <a href="#services" class="page-scroll btn btn-xl">Start Travel</a>
            </div>
        </div>
    </header>

    <!-- Services Section -->
    <section id="services">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Services</h2>
                    <h3 class="section-subheading text-muted">Read The instrcution guide carefully!</h3>
                </div>
            </div>
             <div class="row text-center">

                                   <div class="col-md-4">
                                    <span class="fa-stack fa-4x">
                                         <i class="fa fa-circle fa-stack-2x text-primary"></i>
                                    <i class="fa fa-envelope fa-stack-1x fa-inverse"></i>
                                    </span>
                                    <h4 class="service-heading"><a class="page-scroll" href="#contact">Massage</a></h4>
                                     <p class="text-muted">If you have any ideas about web-site, please leave a message to help us.</p>
                                     </div>

                 <div class="col-md-4">
                    <span class="fa-stack fa-4x">
                        <i class="fa fa-circle fa-stack-2x text-primary"></i>
                        <i class="fa fa-shopping-cart fa-stack-1x fa-inverse fa-spin"></i>
                    </span>
                     <h4 class="service-heading"><a href="E-Service.php">E-Service System</a></h4>
                     <p class="text-muted">Pick the day you want to make your trip and we will do it for you!.</p>
                 </div>

                 <div class="col-md-4">
                    <span class="fa-stack fa-4x">
                        <i class="fa fa-circle fa-stack-2x text-primary"></i>
                        <i class="fa fa-phone fa-stack-1x fa-inverse"></i>
                    </span>
                     <h4 class="service-heading"><font color="orange">Call Center</font></h4>
                     <p class="text-muted"><strong>+998 91 339-89-55 </strong></br>Only emergency cases, Every detail is in the web-site</p>
                 </div>







            </div>
        </div>
    </section>

    <!-- Portfolio Grid Section -->
    <section id="portfolio" class="bg-light-gray">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Trips</h2>
                    <h3 class="section-subheading text-muted">Availlable now!</br>Just Pick the day you want to go and change your life by pressing button GO!.</h3>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 col-sm-6 portfolio-item">
                    <a href="#portfolioModal1" class="portfolio-link" data-toggle="modal">
                        <div class="portfolio-hover">
                            <div class="portfolio-hover-content">
                                <i class="fa fa-plus fa-3x"></i>
                            </div>
                        </div>
                        <img src="img/portfolio/roundicons.png" class="img-responsive" alt="">
                    </a>
                    <div class="portfolio-caption">
                        <h4>India</h4>
                        <p class="text-muted">India tour</p>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 portfolio-item">
                    <a href="#portfolioModal2" class="portfolio-link" data-toggle="modal">
                        <div class="portfolio-hover">
                            <div class="portfolio-hover-content">
                                <i class="fa fa-plus fa-3x"></i>
                            </div>
                        </div>
                        <img src="img/portfolio/startup-framework.png" class="img-responsive" alt="">
                    </a>
                    <div class="portfolio-caption">
                        <h4>Turkey</h4>
                        <p class="text-muted">Turkey tour</p>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 portfolio-item">
                    <a href="#portfolioModal3" class="portfolio-link" data-toggle="modal">
                        <div class="portfolio-hover">
                            <div class="portfolio-hover-content">
                                <i class="fa fa-plus fa-3x"></i>
                            </div>
                        </div>
                        <img src="img/portfolio/treehouse.png" class="img-responsive" alt="">
                    </a>
                    <div class="portfolio-caption">
                        <h4>Italy</h4>
                        <p class="text-muted">Italy tour</p>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 portfolio-item">
                    <a href="#portfolioModal4" class="portfolio-link" data-toggle="modal">
                        <div class="portfolio-hover">
                            <div class="portfolio-hover-content">
                                <i class="fa fa-plus fa-3x"></i>
                            </div>
                        </div>
                        <img src="img/portfolio/golden.jpg" class="img-responsive" alt="">
                    </a>
                    <div class="portfolio-caption">
                        <h4>Azerbaijan Tour</h4>
                        <p class="text-muted">Baku</p>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 portfolio-item">
                    <a href="#portfolioModal5" class="portfolio-link" data-toggle="modal">
                        <div class="portfolio-hover">
                            <div class="portfolio-hover-content">
                                <i class="fa fa-plus fa-3x"></i>
                            </div>
                        </div>
                        <img src="img/portfolio/escape.png" class="img-responsive" alt="">
                    </a>
                    <div class="portfolio-caption">
                        <h4>Malaysia</h4>
                        <p class="text-muted">Malaysia tour</p>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 portfolio-item">
                    <a href="#portfolioModal6" class="portfolio-link" data-toggle="modal">
                        <div class="portfolio-hover">
                            <div class="portfolio-hover-content">
                                <i class="fa fa-plus fa-3x"></i>
                            </div>
                        </div>
                        <img src="img/portfolio/dreams.png" class="img-responsive" alt="">
                    </a>
                    <div class="portfolio-caption">
                        <h4>America</h4>
                        <p class="text-muted">America tour(NEW-YORK)</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
  <!--  <section id="about">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">About</h2>
                    <h3 class="section-subheading text-muted">Something right here!</h3>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <ul class="timeline">
                        <li>
                            <div class="timeline-image">
                                <img class="img-circle img-responsive" src="img/about/1.jpg" alt="">
                            </div>
                            <div class="timeline-panel">
                                <div class="timeline-heading">
                                    <h4>date/year</h4>
                                    <h4 class="subheading">Our Humble Beginnings</h4>
                                </div>
                                <div class="timeline-body">
                                    <p class="text-muted">Maybe something right here!</p>
                                </div>
                            </div>
                        </li>
                        <li class="timeline-inverted">
                            <div class="timeline-image">
                                <img class="img-circle img-responsive" src="img/about/2.jpg" alt="">
                            </div>
                            <div class="timeline-panel">
                                <div class="timeline-heading">
                                    <h4>March 2015</h4>
                                    <h4 class="subheading">story/h4>
                                </div>
                                <div class="timeline-body">
                                    <p class="text-muted">Something right here!</p>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="timeline-image">
                                <img class="img-circle img-responsive" src="img/about/3.jpg" alt="">
                            </div>
                            <div class="timeline-panel">
                                <div class="timeline-heading">
                                    <h4>December 2015</h4>
                                    <h4 class="subheading">Transition to Full Service</h4>
                                </div>
                                <div class="timeline-body">
                                    <p class="text-muted">Something right here!</p>
                                </div>
                            </div>
                        </li>
                        <li class="timeline-inverted">
                            <div class="timeline-image">
                                <img class="img-circle img-responsive" src="img/about/4.jpg" alt="">
                            </div>
                            <div class="timeline-panel">
                                <div class="timeline-heading">
                                    <h4>July 2016</h4>
                                    <h4 class="subheading">Phase Two Expansion</h4>
                                </div>
                                <div class="timeline-body">
                                    <p class="text-muted">Something right here</div>
                            </div>
                        </li>
                        <li class="timeline-inverted">
                            <div class="timeline-image">
                                <h4>Be Part
                                    <br>Of Our
                                    <br>Story!</h4>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>-->

    <!-- Team Section -->
    <section id="team" class="bg-light-gray">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Our Amazing Team</h2>
                    <h3 class="section-subheading text-muted"></h3>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-4">
                    <div class="team-member">
                        <img src="img/team/1.jpg" class="img-responsive img-circle" alt="">
                        <h4>Sabina</h4>
                        <p class="text-muted">Lead Designer</p>
                        <ul class="list-inline social-buttons">
                        
                            <li><a href="https://m.facebook.com/profile.php?id=100013325176061"><i class="fa fa-facebook"></i></a>
                      
                        </ul>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="team-member">
                        <img src="img/team/2.png" class="img-responsive img-circle" alt="">
                        <h4>Anvarbey</h4>
                        <p class="text-muted">First Lead Developer</p>
                        <ul class="list-inline social-buttons">
                            <li><a href="http://anvarmuminov1996@gmail.com/"><i class="fa fa-envelope"></i></a>
                            </li>
                            <li><a href="https://facebook.com/profile.php?id=100004228563544"><i class="fa fa-facebook"></i></a>
                       
                        </ul>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="team-member">
                        <img src="img/team/3.jpg" class="img-responsive img-circle" alt="">
                        <h4>Turabek</h4>
                        <p class="text-muted">Second Lead Developer</p>
                        <ul class="list-inline social-buttons">
                
                            <li><a href="https://www.facebook.com/profile.php?id=100008977295804"><i class="fa fa-facebook"></i></a>
                    
                        </ul>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2 text-center">
                    <p class="large text-muted">We are ambitious students of <a href="https://inha.uz/en/">Inha University in Tashkent</a> who are aiming to increase quality and level of IT-development in Uzbekistan </p>
                </div>
            </div>
        </div>
    </section>

    <!-- Clients Aside -->
    <aside class="clients">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-6">
                    <a href="#">
                        <img src="img/logos/bakufiers.jpg" class="img-responsive img-centered" alt="">
                    </a>
                </div>
                <div class="col-md-3 col-sm-6">
                    <a href="#">
                        <img src="img/logos/tour.png" class="img-responsive img-centered" alt="">
                    </a>
                </div>
                <div class="col-md-3 col-sm-6">
                    <a href="#">
                        <img src="img/logos/uzbek.png" class="img-responsive img-centered" alt="">
                    </a>
                </div>
                <div class="col-md-3 col-sm-6">
                    <a href="#">
                        <img src="img/logos/creative-market.jpg" class="img-responsive img-centered" alt="">
                    </a>
                </div>
            </div>
        </div>
    </aside>

    <!-- Contact Section -->
    <section id="contact">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Contact Us</h2>
                    <h3 class="section-subheading text-muted">Contact us if you have any question!</h3>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <form name="sentMessage" id="contactForm" novalidate>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Your Name *" id="name" required data-validation-required-message="Please enter your name.">
                                    <p class="help-block text-danger"></p>
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control" placeholder="Your Email *" id="email" required data-validation-required-message="Please enter your email address.">
                                    <p class="help-block text-danger"></p>
                                </div>
                                <div class="form-group">
                                    <input type="tel" class="form-control" placeholder="Your Phone *" id="phone" required data-validation-required-message="Please enter your phone number.">
                                    <p class="help-block text-danger"></p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <textarea class="form-control" placeholder="Your Message *" id="message" required data-validation-required-message="Please enter a message."></textarea>
                                    <p class="help-block text-danger"></p>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-lg-12 text-center">
                                <div id="success"></div>
                                <button type="submit" class="btn btn-xl">Send Message</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-4">
           
                </div>
                <div class="col-md-4">
                    <ul class="list-inline social-buttons">
                       
                    </ul>
                </div>
                <div class="col-md-4">
                    <ul class="list-inline quicklinks">

                    </ul>
                </div>
            </div>
        </div>
    </footer>


    <!-- Portfolio Modal 1 -->
    <div class="portfolio-modal modal fade" id="portfolioModal1" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="close-modal" data-dismiss="modal">
                    <div class="lr">
                        <div class="rl">
                        </div>
                    </div>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8 col-lg-offset-2">
                            <div class="modal-body">
                                <!-- Project Details Go Here -->
                                <h2>India</h2>
                                <p class="item-intro text-muted">Amazign impressions in India.</p>
                                <img class="img-responsive img-centered" src="img/portfolio/roundicons-preview.png" alt="">
                                <p>A fusion of modernity and tradition, the vibrant colours of India are truly captivating. Be at one with bustling cities, surrender to the simplicity of villages and be touched by the spirituality of this land. A journey through India is enriching, inspiring and unforgettable.</br>
                                <strong>Details:</strong></br>
<strong>1</strong>
Passport Requirements:</br>
Original passport and one photocopy of passport information and signature page. </br>
The passport must be signed, valid for 6 months beyond stay in India, with at least two blank passport pages available for India visa stamps.</br> Amendment pages in the back of the passport are not suitable for Indian visas.</br>
<strong>2</strong>
India Visa Application Form:</br>
One signed India visa application form plus one copy. </br>
- The traveler must sign their own visa</br> application form, and signatures on the application must match the signature in the applicant's passport. </br>
- The Indian visa application form must be printed on two pages, and signed on both pages. The applicant must sign under the photo on the first page, and at the bottom of the second page. </br>
- This is an online application form. On the Indian Government website, select the orange button on the left that says "Regular Visa Application" to start the visa application form. </br>
- Once you complete the visa application, please print the form. Do not make an appointment and payment at this time 
Please read the India Visa Application Guide before you begin the online visa application form.</br>
Verify and Submit</br>
<strong>3</strong>
Photo Requirements:</br>
One recent 2 x 2 passport type photograph, in color, front view and with a plain/white background. Glasses should not be worn in these photos; photos should not be stapled to the application.</br>

OR - you can upload a passport photo when you place your order, instead of providing physical passport photos.</br>
<strong>4</strong>
Other Forms:</br>
Additional Particulars Form </br>
This form must be printed out, completed and signed by all visa applicants.</br>

San Francisco: The consulate will not accept forms that are handwritten. Type only. Questions that do not apply to the traveler should be answered specifically with "no". The Indian Consulate will not accept "N/A" or "Not Applicable" or "None" as answers.</br>
<strong>5</strong>
Proof of State Residency:</br>
A clear photocopy of the applicant's driver's license or state issued ID is the best proof of address. The address on the ID must match the present address on the visa application exactly. Alternatively, the most recent major utility bill (Water, Gas, Electric, Sewage), or a copy of a valid/current lease containing both the landlord and tenant signature, may also be accepted.</br>

New York: If submitting a utility bill as proof of address the original is required, a photocopy is not accepted.</br>
<strong>6</strong>
Applicants Under the Age of 18:</br>
Atlanta: Parental Authorization For Minors Copy of the minor's birth certificate.</br>

Copy of both parents' signed passports.</br>

If either parent is a foreign citizen: copy of both sides of Permanent Resident Card, Employment Authorization Card or passport pages showing valid, long term US visa.</br>

Minors Signing the Application Form: A minor child should sign their name inside the signature box under the photo on first page of the application. If the child is too young to sign their name, the child's thumbprint must be stamped inside the signature box under the photo on first page of the application. On the second page of the application, the minor child should not sign the application. On the second page of the application, both of the child's parents must sign the application, and both parents' signatures should be notarized. Applications without both parents' notarized signatures will not be accepted.</br>

The visa application must be signed by both parents and notarized. A copy of a parent's driver's license or utility bill can be used for proof of residential address in the US.</br>

Minors of Indian Origin: a minor must submit a copy of the parent's cancelled Indian Passport and a copy of the parent’s Renunciation Certificate. If they have a copy of the cancelled India Passport they may complete a Renunciation certificate and submit it. If they do not have either document, they will need to complete and submit the required documentation for a Deemed Surrender Certificate.</br>
Chicago, Houston and Washington, DC: Original, notarized Parental Authorization For Minors</br>

Copy of the minor's birth certificate.</br>

Copy of both parents' signed passports.</br>

Minors Signing the Application Form: A minor child should sign their name inside the signature box under the photo on first page of the application. If the child is too young to sign their name, the child's thumbprint must be stamped inside the signature box under the photo on first page of the application. On the second page of the application, the minor child should not sign the application. On the second page of the application, both of the child's parents must sign the application, and both parents' signatures should be notarized. Applications without both parents' notarized signatures will not be accepted.</br>

The visa application must be signed by both parents and notarized. A copy of a parent's driver's license or utility bill can be used for proof of residential address in the Uzbekistan.</br>

Minors of Indian Origin: a minor must submit a copy of the parent's cancelled Indian Passport and a copy of the parent’s Renunciation Certificate. If they have a copy of the cancelled India Passport they may complete a Renunciation certificate and submit it. If they do not have either document, they will need to complete and submit the required documentation for a Deemed Surrender Certificate.
New York: Parental Authorization For Minors Copy of the minor's birth certificate.</br>

Copy of both parents' signed passports.</br>

Minors Signing the Application Form: A minor child should sign their name inside the signature box under the photo on first page of the application. If the child is too young to sign their name, the child's thumbprint must be stamped inside the signature box under the photo on first page of the application. On the second page of the application, the minor child should not sign the application. On the second page of the application, both of the child's parents must sign the application, and both parents' signatures should be notarized. Applications without both parents' notarized signatures will not be accepted.</br>

The visa application must be signed by both parents and notarized. A copy of a parent's driver's license or utility bill can be used for proof of residential address in the US.</br>

Minors of Indian Origin: a minor must submit a copy of the parent's cancelled Indian Passport and a copy of the parent’s Renunciation Certificate. If they have a copy of the cancelled India Passport they may complete a Renunciation certificate and submit it. If they do not have either document, they will need to complete and submit the required documentation for a Deemed Surrender Certificate.
San Francisco: Original, notarized Parental Authorization For Minors </br>

Copy of each parents' bank statements Parents' joint account statements are acceptable when showing both parents' names. If the minor is traveling alone, parents' past three bank statements must be provided.</br>

Copy of the minor's birth certificate.</br>

Copy of both parents' signed passports.</br>

Minors Signing the Application Form: A minor child should sign their name inside the signature box under the photo on first page of the application. If the child is too young to sign their name, the child's thumbprint must be stamped inside the signature box under the photo on first page of the application. On the second page of the application, the minor child should not sign the application. On the second page of the application, both of the child's parents must sign the application, and both parents' signatures should be notarized. Applications without both parents' notarized signatures will not be accepted.</br>

The visa application must be signed by both parents and notarized. A copy of a parent's driver's license or utility bill can be used for proof of residential address in the US.</br>

Minors of Indian Origin: a minor must submit a copy of the parent's cancelled Indian Passport and a copy of the parent’s Renunciation Certificate. If they have a copy of the cancelled India Passport they may complete a Renunciation certificate and submit it. If they do not have either document, they will need to complete and submit the required documentation for a Deemed Surrender Certificate.</br>
<strong>7</strong>
Proof of Sufficient Funds:</br>
San Francisco: Applicants with occupation of student, retired or unemployed are recommended to provide three most recent bank statements as evidence of sufficient funds.</br>
<strong>8</strong>
Country of Origin:</br>
For Applicants of Indian Origin: There are additional procedures and visa requirements for applicants of Indian origin, including applicants born in the US to parents of Indian origin. Please carefully review the requirements for applicants of Indian origin and include all necessary documents and fees with the visa application. </br>

For applicants of Pakistani origin: Travisa cannot submit an Indian visa application for Pakistani citizens and applicants of Pakistani origin. These applicants are required to submit visa applications in person. </br>
For applicants of Sri Lankan origin: Additionals form for Sri Lankan nationals.</br> 
For applicants of Bangladeshi origin: Additionals form for Bangladeshi nationals.</br>
This is Travisa's service order form, where you will provide your contact and shipping information, choose the visa processing needed and make your payment. You must print the completed form and send it to Travisa with all other supporting documents.
Click here for India Consular Fees and Visa Processing Times</br>
Visa Validity:</br>

Travelers must leave India on or before the expiration of their visa. Travelers who remain in India beyond the validity of their visa could face detention and significant penalties. If your intended length of stay in India exceeds the validity of your existing visa, you must apply for a new visa.</br>
Visa Processing Time:</br>

Traditional Indian visa processing time varies, typically applications are reviewed at the Indian Consulate for a week or longer. The e-Tourist visa is generally issued within three business days.</br>

INDIA VISA FEE INCREASE AND POSSIBLE DELAYS TO VISA PROCESSING:</br>
The Consulates of India across the U.S. have announced unspecified visa fee increases effective April 1, 2017. Because of these changes the consulates have warned of the potential for submission and processing delays. Please take these delays into account when preparing to apply for your visa application.</br>

Houston: The Consulate of India in Houston is experiencing processing delays due to high seasonal volume. Some delays may occur with the submission and pick up of visa applications. Please take this into account when submitting your visa application.
Register your trip with the US Embassy:</br>
The US State Department strongly encourages American citizens planning international travel to register with the US Embassy(s) in the countries they plan to visit. Registration notifies the US Embassy in each country of your travel plans and enrolls you in the State Department travel advisory and warnings program. Feel more secure about your international travels by having Travisa register your trip with the US Department of State; simply complete the form on your visa application kit after placing your order.</br>
Non-refundable tickets or reservations should not be purchased until all visas and passports are secured and in your possession.</br>
How to Apply for a Visa to India</br>
Review the requirements to apply for your visa
<strong>Gather your documents , Book the day you want to go then
Ship your documents to our office</strong></br>
Where to Apply for Your Indian Visa</br>
Residents of Uzbekista apply for a visa in Tashkent :</br>
Residents of other countries send the message and we will let you know!</br>




                                </p>


                                <button type="button" class="btn btn-primary" ><i class="fa fa-shopping-cart"></i><a href="booking.php">Go!</a></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Portfolio Modal 2 -->
    <div class="portfolio-modal modal fade" id="portfolioModal2" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="close-modal" data-dismiss="modal">
                    <div class="lr">
                        <div class="rl">
                        </div>
                    </div>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8 col-lg-offset-2">
                            <div class="modal-body">
                                <h2>Turkey</h2>
                                <p class="item-intro text-muted">Amazing impressions in Bodrum(Turkey).</p>
                                <img class="img-responsive img-centered" src="img/portfolio/startup-framework-preview.png" alt="">
                                <p> The Bodrum half day tour to Etrim mountain village will be an introduction to authentic Anatolian village life in a nomadic mountain village. It's located fifteen miles outside of Bodrum. Wear comfortable shoes as we will be walking about a half mile over uneven surfaces. In this five hundred year old town, the main occupation of the villagers is still based on farming, animal breeding, and carpet/ kilim weaving.</br>
                                <STRONG>Details</STRONG>
Ordinary Passport Holders from the following Countries are exempt from visa for their travels up to 60 days:
Bosnia-Herzegovina, Macedonia</br>

Ordinary Passport Holders from the following Countries are exempt from visa for their travels up to 30 days:
Costa Rica, Kazakhstan, Kyrgyzstan, Latvia*, Macao Special Administration, Mongolia, Tajikistan, Turkmenistan, Uzbekistan,</br>

Ordinary and official passport holders from the Turkish Republic of Northern Cyprus are exempt from visa.</br>

* Diplomatic and service passport holders are exempt from visa requirement for their travels up to 90 (ninety) days.</br>

Note: The above information is for tourists. If you are going to study or work in Turkey, you must obtain appropriate visa from Turkish diplomatic/consular missions, prior to proceeding to Turkey.
</br>
What documents will be required?</br>
The applicant is required to submit the following documents while applying in person:</br>

- Valid travel document (passport) (It should be valid at least three months longer than the expiry date of the requested visa),
- Completed visa application form, </br>
- One passport size photograph of the applicant (It should be affixed on the top left side of the visa application form),
- Documents supporting the purpose and the conditions of the planned visit (e.g. letter of invitation, travel itinerary, round trip ticket, hotel reservation with payment guarantee etc.),</br>
- Guarantees regarding means of subsistence,</br>
- Non-refundable visa processing fee (the amount differs depending on the nationality and visa type),</br>
- If the person applies from a country other than his/her homeland, then he/she should also submit his/her valid residence permit or any document that proves he/she legally stays in that country.</br>
- If the person applies for a business visa, an invitation letter from the counterpart company is also required in addition to the above mentioned documents.</br>

Note: Please be informed that the requested documents may vary according to the local conditions where the Turkish Embassy/Consulate is based.</br>

Note: If the relevant Turkish Embassy/Consulate exceptionally receives the visa applications by mail or by courier service, the applicant must send the above mentioned documents and also a pre-paid or self-stamped return envelope (DHL, Fed Ex, Express, UPS, or some sort of insured/certified mail is highly recommended, since the original passport will be returned inside that envelope). Please contact with the nearest Turkish Embassy/Consulate to learn whether they receive the applications by mail or not.</br>

If the person prefers to obtain the entry visa at a Turkish border gate, then he/she will be required to have the following documents:
- Valid travel document (passport) (It should be valid at least three months longer than the expiry date of the visa requested.)
- Non-refundable visa processing fee (the amount differs depending on the nationality and visa type)</br>

Only holders of passports from the follwoing countries can apply for entry visa at a Turkish border gate: 
USA, Albania, Australia, Austria, Bahrain, Belarus, Belgium, Armenia, Estonia, Greek Cypriot Adm., Netherlands, Hong Kong (BNO), United Kingdom, Ireland, Spain, Canada, Lithuania, Hungary, Moldova, Montenegro, Norway, Poland, Portugal, Romania, Russian Fed., Serbia, Slovakia, Slovenia, Ukraine, Jordan, Malta, Oman, UAE (*), Qatar (*), Kuwait (*), Saudi Arabia (*), Antigua - Barbuda, Bahamas, Barbados, Dominica, Dominican Republic, Grenada, Haiti, Jamaica, Maldives, St. Christopher Nevis, St. Lucia, St. Vincent and the Grenadines, South Africa, Mauritius, Kosovo.</br>

(*) Only until 31 October 2009.</br>

Time required to issue a visa:
Dependent on nationality of applicant. Minimum of 1 day but some applications may be referred to the Ministry of Foreign Affairs in Ankara which may take much longer.
</br>
How do I apply?</br>
Passport holders from the following countries can apply for tourist visas at the Turkish border gate: 
USA, Albania, Australia, Austria, Bahrain, Belarus, Belgium, Armenia, Estonia, Greek Cypriot Adm., Netherlands, Hong Kong (BNO), United Kingdom, Ireland, Spain, Canada, Lithuania, Hungary, Moldova, Montenegro, Norway, Poland, Portugal, Romania, Russian Fed., Serbia, Slovakia, Slovenia, Ukraine, Jordan, Malta, Oman, UAE (*), Qatar (*), Kuwait (*), Saudi Arabia (*), Antigua - Barbuda, Bahamas, Barbados, Dominica, Dominican Republic, Grenada, Haiti, Jamaica, Maldives, St. Christopher Nevis, St. Lucia, St. Vincent and the Grenadines, South Africa, Mauritius, Kosovo.
</br>
Alternatively you can apply to your nearest Consulate of Consular section at Embassy; see Contact Addresses section.</br>

What is the cost of a visa?</br>
Tourist/Work Single-entry visa; Tourist/Work Multiple-entry visa; Education, Residence, Study and Long Term Multiple-entry visa; and Transit visa. Prices vary according to nationality. Some visas must be obtained in advance. Contact the Consulate (or Consular section at Embassy) for the up to date prices (see the link below for embassy contact info);
</br>
How long is the visa valid for?</br>
There are two types of visas in the Turkish practice:</br>
1) Entry visa (single entry, multiple entry and entry with special annotations)</br>
2) Transit visa (single and double transit)</br>

- Single entry visa is valid for one year and allows its holder, depending on the nationality and passport type, to stay in Turkey up to three months and to visit the country only one time. </br>
- Multiple entry visa is valid for up to five years and allows its holder to make multiple visits and, depending on the nationality and passport type he/she can stay one to three months each time he/she enters into Turkey. </br>
- Transit visa is valid for up to three months and allows the person to travel to another country through transiting the Turkish territory.
</br>
If the connecting flight to the third country does not require an overnight stay in Turkey, then no visa is necessary. In other words, Turkey does not issue Airport Transit Visa (ATV).</br>

The passengers of cruise ships are allowed to enter and stay overnight in the port cities of Turkey upon the permission given by local border police authorities. These passengers are not required to obtain an entry visa to Turkey.
</br>
Other information: </br>
Residence Permits: </br>
An entry visa enables the bearer to stay in Turkey for the duration stated on the visa sticker. However, if the person intends or is obliged to stay in Turkey longer than the permitted duration, this extension is subject to the approval of the Ministry of Interior. In this case, the person has to obtain a residence permit.</br>

Applications for residence permits should be made to the Alien’s Branch of Local Police Departments (Emniyet Mudurlugu Yabancilar Subesi) within 30 days upon arrival at Turkey. Applicants are generally required to submit work permit, work visa, education visa or research visa and a letter describing his/her circumstances (i.e. employment, education, marriage to a Turkish citizen).</br>

Once the person is granted with the residence permit, he/she can enter into Turkey multiple times as long as his/her residence permit is valid and thus he/she does not need a visa for entry into Turkey. If the extension of the residence permit is required, the extension or renewal should be made timely before the expiry date. The person is recommended to have the validity of the residence permit extended before leaving Turkey, if the validity of residence permit is to expire or has already expired.</br>

Embassy contact information:</br>
Please contact the nearest Embassy of Turkey for information on what documentation you may require to enter Turkey.</br>



 

<strong>Disclaimer</strong>: The contents of these pages are provided as an information guide only, in good faith. The use of this website is at the viewer/user's sole risk. While every effort is made in presenting up-to-date and accurate information, no responsibility or liability is accepted by the owners to this website for any errors, omissions, outdated or misleading information on these pages or any site to which these pages connect or are linked.</br>

Source & Copyright: The source of the above visa and immigration information and copyright owner/s is the:
- Republic of Turkey Ministry of Foreign Affairs - URL: www.mfa.gov.tr
- e-Konsolosluk Hakkında - URL: www.e-konsolosluk.net</br>

The viewer/user of this web page should use the above information as a guideline only, and should always contact the above sources or the user's own government representatives for the most up-to-date information at that moment in time, before making a final decision to travel to that country or destination.
</br>
                                </p>

                                <button type="button" class="btn btn-primary" ><i class="fa fa-shopping-cart"></i><a href="booking.php">Go!</a></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Portfolio Modal 3 -->
    <div class="portfolio-modal modal fade" id="portfolioModal3" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="close-modal" data-dismiss="modal">
                    <div class="lr">
                        <div class="rl">
                        </div>
                    </div>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8 col-lg-offset-2">
                            <div class="modal-body">
                                <!-- Project Details Go Here -->
                                <h2>Venice tour(Italy)</h2>
                                <p class="item-intro text-muted">Amazing impressions in Venice.</p>
                                <img class="img-responsive img-centered" src="img/portfolio/treehouse-preview.png" alt="">
                                <p>A single day. A unique opportunity. Discover Venice and its two small islands including the most interesting sites and experiences. Rialto Bridge, St. Mark’s Basilica, a bird’s-eye view of St. Mark’s Square, and the Doge’s Palace are some of the larger, most famous things to see on this tour. We’ll also visit quieter, lesser known locations including hidden streets and picturesque piazzas. From these off the beaten path spots, you’ll get a feel for what it is like living life on the floating city.</br>
 The instructions given on this website are to help you prepare your documents in the best way possible. This will reduce the risk that the application is incomplete and take longer to process. Click on the process map below to read the description and understand each process step in detail.</br>


Applicants are strongly encouraged to file their application at least 15 working days prior to the date of departure and not more than 90 days before departure. This will allow an orderly examination of the applications and limit the chances for delay in decisions on visa applications. 
</br>


Step 1</br>

Check if you need a Visa
</br>

Step 2</br>

Choose your visa type</br>


Step 3</br>

Prepare your application
</br>

Step 4</br>

Schedule an appointment
</br>

Step 5</br>

Visit the Visa Application Centre
</br>

Step 6</br>

Post submission process
</br>

Step 7</br>

Collection of Passport</br>


Note: Under few circumstances your passport cannot be couriered, even if you opt for it and you may </br>


have to collect it personally from nearest VFS Visa Application Centre.</br>






                                </p>

                               <button type="button" class="btn btn-primary" ><i class="fa fa-shopping-cart"></i><a href="booking.php">Go!</a></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Portfolio Modal 4 -->
    <div class="portfolio-modal modal fade" id="portfolioModal4" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="close-modal" data-dismiss="modal">
                    <div class="lr">
                        <div class="rl">
                        </div>
                    </div>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8 col-lg-offset-2">
                            <div class="modal-body">
                                <!-- Project Details -->
                                <h2>Azerbaijan</h2>
                                <p class="item-intro text-muted">Amazing impressions in Baku.</p>
                                <img class="img-responsive img-centered" src="img/portfolio/golden-preview.jpg" alt="">
                                <p>Azerbaijan tours will introduce you the country on the shores of the Caspian Sea, rich in ancient historical monuments, sanatoriums and picturesque nature. You will discover modern Baku and unique Old Town, thermal springs of Ganja and Naftalan, the center of carpet weaving in Quba, delicious Azerbaijan cuisine and many more.

The most popular Azerbaijan tours are cultural, beach and spa (sanatorium) holiday programs. The guided tours offer you the popular tourist places in Azerbaijan: Shamakhi, Baku, Sheki, Quba and others.

Kabala and Nakhichevan, the oldest cities in South Caucasus, are famous for keeping unique national essence. Baku, the capital of Azerbaijan, does not differ from a modern European city at the first glance: modern architecture, numerous hotels and restaurants, landscaped parks and wide squares with fountains. At the same time, the old part of Baku preserved its historic spirit: residential courtyards and narrow cobbled streets are the same, as they were 40 years ago, when famous Soviet film “The Diamond Arm” was shot there.

Azerbaijan is an ideal destination for a family holiday. The sandy beaches of the Caspian Sea, many parks, attractions, shopping and entertainment centers offer diverse leisure time as for parents so for children.

Masally, Naphthalene, Baku, Ganja are the best for SPA-tours as they are famous for thermal, mineral and naftalan sources and springs. Spa tour programs offer treatment, séances in salt caves, and sanatoriums in beautiful Azerbaijani.

Azerbaijan tours perfectly blend visiting ancient and modern monuments and exploring local cuisine, museums, traditions, wine, and carpets. Holiday in this beautiful Caucasian country with plenty of sun and fruits, colorful and hospitable people, beautiful and diverse nature, smells of the sea, excellent hotels and good shopping will stay in your memory forever.</br>
<strong>Details:</strong>
All travelers to Azerbaijan (apart from citizens of most CIS countries) should obtain entry visa before they travel. Citizens of Bahrain, China, Kuwait, Israel, Japan, Malaysia, Oman, Qatar, Saudi Arabia, Singapore, South Korea, Turkey, United Arab Emirates have the opportunity to obtain visas in Azerbaijan international airports (Baku, Ganja, Nakhichevan) upon arrival (starting from 1 February 2016). US citizens travelling by the New York-Baku direct flight on Azerbaijan Airlines (AZAL) are also eligible to obtain short stay single entry (up to 30 days) Azerbaijani visa upon arrival at the Heydar Aliyev International Airport in Baku. All other citizens have to have their visas ready before traveling to Azerbaijan</br>

There are now 2 ways to obtain tourist visa to Azerbaijan.</br>

The first way is to apply for evisa (sample of e-visa). This is the most convenient way to secure an entry visa to Azerbaijan. The advantages of evisa is lower cost, online process only (no need to visit embassies or send your passport to them), you get a visa to your email as PDF attachment that you just need to print out. You can enter Azerbaijan at any border entry point with this type of visa. One can apply for evisa for up to 1 year before the planned entry date to Azerbaijan.
</br>
The cost of evisa is only 20$ for all nationals and it takes up to 3 days to be ready. The visa will have 30 days validity starting from the day that you put as your arrival day to AZ in request form. To apply directly one should proceed to http://evisa.gov.az and will only need to fill visa request form, upload a scan of the passport, pay a visa fee and then wait when it is ready and emailed to applicant's email address. You might enter AZ later than the visa start day but within the 30 days validity period. Electronic visas will be issued only to nationals of 81 countries listed here. All other nationals will need to apply for visa only through embassies of AZ (see below).
</br>
The second way is to apply for visa in a traditional way through the embassy/consulate of Azerbaijan republic abroad. To obtain tourist visa in this way you will need an official Letter of Invitation (LOI) from travel agency licensed by Azerbaijan Ministry of Culture and Tourism. Visa support letter has to be on a headed paper, duly stamped and signed. Invitation letter has to be submitted to consular section of Azeri embassy along with application form, two passport-size (3x4 cm) photos and original passport/travel document (must be valid for at least 6 months after the expiry date of the Azerbaijani visa you apply for). It will allow applicant to obtain single entry 30 days tourist visa.
</br>
Azerbaijan24.com can provide you with needed visa support documents and guide you through whole process. We still DO RECOMMEND to apply for evisa as the process is much easier and will save you both time & money. 
</br>
To proceed with a visa support for getting tourist visa via traditional way please make a payment (ask for invoice to pay) of $60 USD, send a scanned copy of your passport along with the following information:

</br>

Full Name</br>
Passport number</br>
Citizenship</br>
Duration of stay</br>
Arrival date</br>
Planned Accommodation (Hotel, Hostel, Friend)</br></br>
Your contact details</br>
Place of applying for visa (in what country, city)</br>
We aim to process all requests within 24 hours (excluding Sundays). Based on the information received we will issue a Letter of Invitation and send scanned copies of LOI & Tourist Voucher to your email within 24 hours. You will need to print off the documents that we will send you and enclose with application form (some embassies have different forms, so its worth checking their websites. For those applying in London, application form should be filled online on Visa Centre's website) that you will submit to the embassy.
</br>
N.B. If your visa is rejected for some reason we refund that fee in full minus bank transfer fees if there are any.</br>

Please note that additional consular fees are paid at the embassy with your visa application. Azerbaijan24.com provide you with tourist vouchers that entitle you to a reduced visa fee of just 20 USD, in other words instead of paying full standard visa fee in the embassy (ranging from 40 to 130 USD depending on the length of your stay and the country of your citizenship) you will pay just 20 USD. Tourist vouchers are provided as part of visa support package only. Bear in mind, that tourist vouchers might not work in some embassies (though they have to be accepted by any Azeri consulate), and you will be charged the full standard visa fee instead of $20. Unfortunately, we have no opportunities to influence embassies on this matter. We also make no refund if vouchers does not work for reduced visa fee. Refunds are made only if the visa is rejected. For situation with the vouchers in some embassies check the embassy report.  </br>




</p>

                                <button type="button" class="btn btn-primary" data-dismiss="modal"><i class="fa fa-times"></i><a href="booking.php">Go!</a></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Portfolio Modal 5 -->
    <div class="portfolio-modal modal fade" id="portfolioModal5" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="close-modal" data-dismiss="modal">
                    <div class="lr">
                        <div class="rl">
                        </div>
                    </div>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8 col-lg-offset-2">
                            <div class="modal-body">
                                <!-- Project Details Go Here -->
                                <h2>Malaysia</h2>
                                <p class="item-intro text-muted">Amazing impressions in Malaysia.</p>
                                <img class="img-responsive img-centered" src="img/portfolio/escape-preview.png" alt="">
                                <p>Enjoy some of the best tour packages we have to offer that will bring you on a journey to experience Malaysia in all its cultural richness and natural splendour. From the cosmopolitan sights of Kuala Lumpur to the vast richness of the Borneo rainforest and cultural sights of Penang to the myths and legends of mysterious Langkawi, these tours are guaranteed to spellbind and amaze you!</br>
Step 1 :    Before applying, please ensure you are very clear on your ‘purpose of visit’ – do remember we are here to assist and help you through the entire visa application process but are not permitted to advise or guide you on choosing a visa category. Since our work is primarily administrative in nature, we have no say on whether you will be granted a visa and how long it will take to process, as this is entirely the prerogative of the Consulate. You may refer to the link ‘All about Visas’ to understand details of various visas.</br>
Step 2 :    Complete your visa application form and affix your photograph. You may download the form from this websites.</br>
Step 3 :    Ensure photos are as per specifications.</br>
Step 4 :    Attach all supporting documents required as per checklist. Make sure your application is complete. Incomplete applications are not accepted.</br>
Step 5 :    Submit your application at the VFS Malaysia Visa Application Centres in Kolkata, Chandigarh, Bangalore, Hyderabad, Pune and Ahmedabad along with the applicable fees in cash and Demand Draft as applicable.</br>
Step 6 :    Track your application online.</br>
Step 7 :    Collect your passport from the VFS Centre or wait for courier delivery.</br>


                                </p>

                                <button type="button" class="btn btn-primary" data-dismiss="modal"><i class="fa fa-times"></i><a href="booking.php"></a>GO!</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Portfolio Modal 6 -->
    <div class="portfolio-modal modal fade" id="portfolioModal6" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="close-modal" data-dismiss="modal">
                    <div class="lr">
                        <div class="rl">
                        </div>
                    </div>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8 col-lg-offset-2">
                            <div class="modal-body">
                                <!-- Project Details Go Here -->
                                <h2>America</h2>
                                <p class="item-intro text-muted">Amazing impressions in New-York.</p>
                                <img class="img-responsive img-centered" src="img/portfolio/dreams-preview.png" alt="">
                                <p>Enjoy this new and improved small group sightseeing tour of the best attractions in New York City! Unlike the other New York sightseeing tours, your personal tour guide will hop off with you at each stop, showing you New York City in detail.</br>
                                Step 1</br>
Complete the Nonimmigrant Visa Electronic Application (DS-160) form.</br>

Step 2</br>
Pay the visa application fee.</br>
</br>
Step 3</br>
Schedule your appointment on this web page. You need the following three pieces of information in order to schedule your appointment:</br>

Your passport number.</br>
The receipt number from your Visa Fee receipt. (Click here if you need help finding this number.)</br>
The ten (10) digit barcode number from your DS-160 confirmation page.</br>
Step 4</br>
Visit the Consulate General on the date and time of your visa interview. You must bring a printed copy of your appointment letter, your DS-160 confirmation page, one photograph taken within the last six months, and your current and all old passports. Applications without all of these items will not be accepted.</br>

Supporting Documents</br>
Supporting documents are only one of many factors a consular officer will consider in your interview. Consular officers look at each application individually and consider professional, social, cultural, and other factors during adjudication. Consular officers may look at your specific intentions, family situation, and your long-range plans and prospects within your country of residence. Each case is examined individually and is accorded every consideration under the law.</br>

Caution: Do not present false documents. Fraud or misrepresentation can result in permanent visa ineligibility. For security reasons, sealed envelopes are not permitted into the Consulate General; consular officials are not permitted to open sealed envelopes. The Consulate General will not make this information available to anyone and will respect the confidentiality of the information.</br>

You must bring the following documents to your interview. Original documents are always preferred over photocopies and you must bring these documents with you to the interview. Do not fax, email or mail any supporting documents to the Consulate General.</br>

Current proof of income, tax payments, property or business ownership, or assets.</br>
Your travel itinerary and/or other explanation about your planned trip.</br>
A letter from your employer detailing your position, salary, how long you have been employed, any authorized vacation, and the business purpose, if any, of your U.S. trip.</br>    
Criminal/court records pertaining to any arrest or conviction anywhere, even if you completed your sentence or were later pardoned.</p>

                                <button type="button" class="btn btn-primary" data-dismiss="modal"><i class="fa fa-times"></i> <a href="booking.php">GO!</a></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery -->
    <script src="vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>

    <!-- Contact Form JavaScript -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>

    <!-- Theme JavaScript -->
    <script src="js/agency.min.js"></script>

</body>

</html>
